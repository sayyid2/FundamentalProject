package com.sayyid.sub1bysayyid.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface FavUserDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(favUser: FavUser)

    @Update
    fun update(favUser: FavUser)

    @Delete
    fun delete(favUser: FavUser)

    @Query("SELECT * FROM favUser WHERE username = :username")
    fun getFavUser(username: String):LiveData<FavUser>

    @Query("SELECT * FROM favUser ORDER BY username ASC")
    fun getAllFavUser(): LiveData<List<FavUser>>
}