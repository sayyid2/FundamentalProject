package com.sayyid.sub1bysayyid.ui.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.sayyid.sub1bysayyid.data.response.GithubResponse
import com.sayyid.sub1bysayyid.data.response.ItemsItem
import com.sayyid.sub1bysayyid.data.retrofit.ApiConfig
import com.sayyid.sub1bysayyid.ui.SettingPreferences
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainViewModel(private val pref: SettingPreferences) :ViewModel() {
    private val _itemsItem = MutableLiveData<List<ItemsItem>>()
    val itemsItem: LiveData<List<ItemsItem>> = _itemsItem
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    companion object {
        const val TAG = "MainViewModel"
        private const val GITHUB_ID = "arif"
    }

    init {
        findPeople(GITHUB_ID)
    }
    fun findPeople(str:String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getGithub(str)
        client.enqueue(object : Callback<GithubResponse> {
            override fun onResponse(
                call: Call<GithubResponse>,
                response: Response<GithubResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _itemsItem.value = response.body()?.items
                }else{
                    Log.e(TAG, "onResponse: ${response.message()}")
                }
            }


            override fun onFailure(call: Call<GithubResponse>, t: Throwable) {
                _isLoading.value =false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }
    fun getThemeSettings(): LiveData<Boolean> {
        return pref.getThemeSetting().asLiveData()
    }

    fun saveThemeSetting(isDarkModeActive: Boolean) {
        viewModelScope.launch {
            pref.saveThemeSetting(isDarkModeActive)
        }
    }
}