package com.sayyid.sub1bysayyid.ui.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.sayyid.sub1bysayyid.R
import com.sayyid.sub1bysayyid.data.response.ItemsItem
import com.sayyid.sub1bysayyid.databinding.ActivityFavBinding
import com.sayyid.sub1bysayyid.ui.Adapter.ItemAdapter
import com.sayyid.sub1bysayyid.ui.viewmodel.FavViewModel
import com.sayyid.sub1bysayyid.ui.viewmodel.ViewModelFactory

class FavActivity: AppCompatActivity() {
    private lateinit var binding: ActivityFavBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val adapter= ItemAdapter()
        binding.rvFav.adapter = adapter

        val favViewModel=getViewModel(this@FavActivity)


        favViewModel.apply {
            getAllFavUser().observe(this@FavActivity) { users ->
                val items = arrayListOf<ItemsItem>()
                users.map {
                    val item = ItemsItem(login = it.username, avatarUrl = it.avatarUrl)
                    items.add(item)
                }
                adapter.submitList(items)
                binding.rvFav.adapter=adapter
            }
        }
        val layoutManager = LinearLayoutManager(this)
        binding.rvFav.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvFav.addItemDecoration(itemDecoration)


        binding.topAppbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu1 -> {
                    val intent = Intent(this, AboutActivity::class.java)
                    startActivity(intent)
                    true
                }

                R.id.night_mode -> {
                    val intent = Intent(this, SettingActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.favorite -> {
                    val intent = Intent(this, FavActivity::class.java)
                    startActivity(intent)
                    true
                }

                else -> false
            }
        }

    }

    private fun getViewModel(activity: AppCompatActivity): FavViewModel {
        val factory = ViewModelFactory.getInstanceViewModel(activity.application)
        return ViewModelProvider(activity, factory)[FavViewModel::class.java]
    }
}