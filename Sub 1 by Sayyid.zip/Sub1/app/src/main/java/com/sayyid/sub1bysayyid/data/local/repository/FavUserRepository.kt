package com.sayyid.sub1bysayyid.data.local.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.sayyid.sub1bysayyid.data.local.FavUser
import com.sayyid.sub1bysayyid.data.local.FavUserRoomDatabase
import com.sayyid.sub1bysayyid.data.response.ItemsItem
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FavUserRepository(application: Application) {
    private val db = FavUserRoomDatabase.getDatabase(application)
    private val favUserDao = db.favUserDao()
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()

    fun getFavUser(username: String): LiveData<FavUser> {
        return favUserDao.getFavUser(username)
    }

    fun getAllFavUser(): LiveData<List<FavUser>> {
        return favUserDao.getAllFavUser()
    }

    fun insertFavUser(favUser: FavUser) {
        executorService.execute { favUserDao.insert(favUser) }
    }

    fun deleteFavUser(favUser: FavUser) {
        executorService.execute { favUserDao.delete(favUser) }
    }

}