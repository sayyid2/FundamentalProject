package com.sayyid.sub1bysayyid.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sayyid.sub1bysayyid.data.local.FavUser
import com.sayyid.sub1bysayyid.data.local.repository.FavUserRepository
import com.sayyid.sub1bysayyid.data.response.DetailUserResponse
import com.sayyid.sub1bysayyid.data.response.ItemsItem
import com.sayyid.sub1bysayyid.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserDetailViewModel(application:Application):ViewModel() {

    private val repo= FavUserRepository(application)

    private val _follower = MutableLiveData<List<ItemsItem>>()
    val follower: LiveData<List<ItemsItem>> = _follower
    private val _following = MutableLiveData<List<ItemsItem>>()
    val following: LiveData<List<ItemsItem>> = _following


    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    private val _dataUser = MutableLiveData<DetailUserResponse>()
    val dataUser: LiveData<DetailUserResponse> = _dataUser



    fun getDataUser(id: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getDetailUser(id)
        client.enqueue(object : Callback<DetailUserResponse> {
            override fun onResponse(
                call: Call<DetailUserResponse>,
                response: Response<DetailUserResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _dataUser.value = response.body()
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<DetailUserResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    fun getFollowing(username: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getFollowing(username)
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _following.value = response.body()
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    fun getFollower(username: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getFollowers(username)
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ){
                _isLoading.value = false
                if (response.isSuccessful) {
                    _follower.value = response.body()
                }else{
                    Log.e(TAG, "onFailure: ${response.message()}")

                }
            }
            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    fun addFavUser(favUser: FavUser) {
        repo.insertFavUser(favUser)
    }

    fun deleteFavUser(favUser: FavUser) {
        repo.deleteFavUser(favUser)
    }

    fun getFavUser(username: String): LiveData<FavUser> {
        return repo.getFavUser(username)
    }

    companion object {
        private const val TAG = "UserDetailViewModel"
    }
}