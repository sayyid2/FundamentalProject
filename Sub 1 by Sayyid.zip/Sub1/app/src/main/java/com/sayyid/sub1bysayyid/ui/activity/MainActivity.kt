package com.sayyid.sub1bysayyid.ui.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.sayyid.sub1bysayyid.R
import com.sayyid.sub1bysayyid.data.response.ItemsItem
import com.sayyid.sub1bysayyid.databinding.ActivityMainBinding
import com.sayyid.sub1bysayyid.ui.Adapter.ItemAdapter
import com.sayyid.sub1bysayyid.ui.SettingPreferences
import com.sayyid.sub1bysayyid.ui.dataStore
import com.sayyid.sub1bysayyid.ui.viewmodel.MainVMFactory
import com.sayyid.sub1bysayyid.ui.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding


    companion object {
        private const val TAG = "MainActivity"
        private const val ID = "sayyid2"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        supportActionBar?.hide()

        val pref = SettingPreferences.getInstance(application.dataStore)
        val viewModel =
            ViewModelProvider(this, MainVMFactory(pref))[MainViewModel::class.java]

        //mendapatkan theme dark mode
        viewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }

        //mendapatkan data dari API dengan fungsi yang dibuat dibawah
        viewModel.itemsItem.observe(this) {
            setListPeople(it)
        }
        viewModel.isLoading.observe(this) {
            showLoading(it)
        }

        val layoutManager = LinearLayoutManager(this)
        binding.rvReview.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvReview.addItemDecoration(itemDecoration)

        //searchBar
        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView.editText
                .setOnEditorActionListener { _, _, _ ->
                    searchBar.text = searchView.text
                    viewModel.findPeople(searchBar.text.toString())
                    searchView.hide()
                    false
                }
        }

        //menu
        binding.topAppbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu1 -> {
                    val intent = Intent(this, AboutActivity::class.java)
                    startActivity(intent)
                    true
                }

                R.id.night_mode -> {
                    val intent = Intent(this, SettingActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.favorite -> {
                    val intent = Intent(this, FavActivity::class.java)
                    startActivity(intent)
                    true
                }

                else -> false
            }
        }
    }

    //fungsi untuk menunjukan loading
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }


    // fungsi untuk meengambil data dari API
    private fun setListPeople(people: List<ItemsItem>) {
        val adapter = ItemAdapter()
        adapter.submitList(people)
        binding.rvReview.adapter = adapter
    }
}