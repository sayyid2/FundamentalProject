package com.sayyid.sub1bysayyid.ui.activity

import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.sayyid.sub1bysayyid.R
import com.sayyid.sub1bysayyid.data.local.FavUser
import com.sayyid.sub1bysayyid.data.response.DetailUserResponse
import com.sayyid.sub1bysayyid.databinding.ActivityUserDetailBinding
import com.sayyid.sub1bysayyid.ui.Adapter.SectionsPagerAdapter
import com.sayyid.sub1bysayyid.ui.viewmodel.UserDetailViewModel
import com.sayyid.sub1bysayyid.ui.viewmodel.ViewModelFactory

class UserDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserDetailBinding
    private lateinit var userViewModel: UserDetailViewModel
    private var isFav=false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userViewModel = getViewModel(this@UserDetailActivity)


        userViewModel.dataUser.observe(this) {
            setDataUser(it)

            val favUser= FavUser(it.login, it.avatarUrl)
            userViewModel.getFavUser(it.login).observe(this){ favUs->
                binding.loveBtn.apply {
                    if (favUs != null){
                        binding.loveBtn.setImageResource(R.drawable.baseline_favorite_24)
                        binding.loveBtn.setOnClickListener {userViewModel.deleteFavUser(favUs)}
                    }else{
                        binding.loveBtn.setImageResource(R.drawable.baseline_favorite_border_24)
                        binding.loveBtn.setOnClickListener {userViewModel.addFavUser(favUser)}
                    }
                }
            }
        }
        userViewModel.isLoading.observe(this) {
            showLoading(it)
        }


        val nickname = intent.getStringExtra("username")
        nickname?.let {
            userViewModel.getDataUser(it)
//            userViewModel.getFollowing(it)

        }

        supportActionBar?.elevation = 0f





        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        sectionsPagerAdapter.username = nickname.toString()

        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

    }

    private fun setDataUser(it: DetailUserResponse) {
        Glide.with(this)
            .load(it.avatarUrl)
            .circleCrop()
            .into(binding.profile)
        binding.tvName.text = it.name
        binding.tvUsername.text = it.login
        binding.following.text = it.following.toString()
        binding.followers.text = it.followers.toString()
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun getViewModel(activity: AppCompatActivity): UserDetailViewModel {
        val factory = ViewModelFactory.getInstanceViewModel(activity.application)
        return ViewModelProvider(activity, factory)[UserDetailViewModel::class.java]
    }

    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.following,
            R.string.followers
        )

    }
}
