package com.sayyid.sub1bysayyid.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.CompoundButton
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.switchmaterial.SwitchMaterial
import com.sayyid.sub1bysayyid.R
import com.sayyid.sub1bysayyid.ui.SettingPreferences
import com.sayyid.sub1bysayyid.ui.dataStore
import com.sayyid.sub1bysayyid.ui.viewmodel.MainVMFactory
import com.sayyid.sub1bysayyid.ui.viewmodel.MainViewModel
import com.sayyid.sub1bysayyid.ui.viewmodel.ViewModelFactory

class SettingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        val switchTheme = findViewById<SwitchMaterial>(R.id.switch_theme)

        val pref = SettingPreferences.getInstance(application.dataStore)
        val mainViewModel = ViewModelProvider(this, MainVMFactory(pref))[MainViewModel::class.java]

        //fungsi untuk mengubah tema saat switch true dan false
        mainViewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                switchTheme.isChecked = true
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                switchTheme.isChecked = false
            }
        }

        // menyimpan tema bedasarkan switch on/off
        switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            mainViewModel.saveThemeSetting(isChecked)
        }


    }

}