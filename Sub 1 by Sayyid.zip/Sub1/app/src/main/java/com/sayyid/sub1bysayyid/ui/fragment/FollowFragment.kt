package com.sayyid.sub1bysayyid.ui.fragment

import android.app.Application
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.sayyid.sub1bysayyid.data.response.ItemsItem
import com.sayyid.sub1bysayyid.databinding.FragmentFollowBinding
import com.sayyid.sub1bysayyid.ui.Adapter.ItemAdapter
import com.sayyid.sub1bysayyid.ui.viewmodel.UserDetailViewModel
import com.sayyid.sub1bysayyid.ui.viewmodel.ViewModelFactory


class FollowFragment : Fragment() {

    private val followViewModel by viewModels<UserDetailViewModel>{
        ViewModelFactory.getInstanceViewModel(application = Application())
    }

    private var binding : FragmentFollowBinding? =null

    private lateinit var adapter : ItemAdapter


    private var position:Int?=0
    private var username:String?=""


    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding?.progressBar?.visibility = View.VISIBLE
        } else {
            binding?.progressBar?.visibility = View.GONE
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        followViewModel.isLoading.observe(viewLifecycleOwner){
            showLoading(it)
        }
        binding = FragmentFollowBinding.inflate(inflater, container, false)
        return binding?.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ItemAdapter()

        binding?.rvReview?.layoutManager=LinearLayoutManager(requireActivity())
        binding?.rvReview?.adapter=this@FollowFragment.adapter



        arguments?.let {
            position = it.getInt(ARG_POSITION)
            username = it.getString(ARG_USERNAME)
        }
        if (position == 1){
            username?.let { followViewModel.getFollowing(it) }
            binding?.rvReview?.removeAllViews()
            followViewModel.following.observe(viewLifecycleOwner){
                FollowList(it)
            }
        } else {
            username?.let { followViewModel.getFollower(it) }
            binding?.rvReview?.removeAllViews()
            followViewModel.follower.observe(viewLifecycleOwner){
                FollowList(it)
            }
        }
    }

    private fun FollowList(item:List<ItemsItem>){
        val adapter = ItemAdapter()
        adapter.submitList(item)
        binding?.rvReview?.adapter=adapter
    }
    companion object {
        const val ARG_USERNAME = "username"
        const val ARG_POSITION = "position"
    }
}