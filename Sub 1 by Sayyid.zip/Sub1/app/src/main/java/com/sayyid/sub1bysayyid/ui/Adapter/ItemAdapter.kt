package com.sayyid.sub1bysayyid.ui.Adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sayyid.sub1bysayyid.data.response.ItemsItem
import com.sayyid.sub1bysayyid.databinding.ItemPeopleBinding
import com.sayyid.sub1bysayyid.ui.activity.UserDetailActivity

class ItemAdapter:ListAdapter<ItemsItem, ItemAdapter.MyViewHolder> (DIFF_CALLBACK){
    class MyViewHolder (private val binding: ItemPeopleBinding):RecyclerView.ViewHolder(binding.root){
        fun bind(people:ItemsItem){
            binding.usesrName.text=people.login.toString()
            Glide.with(binding.root.context)
                .load(people.avatarUrl)
                .circleCrop()
                .centerCrop()
                .into(binding.userImage)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemPeopleBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return MyViewHolder(binding)

    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val people= getItem(position)
        holder.bind(people)
        holder.itemView.setOnClickListener {
            val intent= Intent(holder.itemView.context, UserDetailActivity::class.java)
            intent.putExtra("username",people.login)
            holder.itemView.context.startActivity(intent)
        }
    }

    companion object{
        val DIFF_CALLBACK=object : DiffUtil.ItemCallback<ItemsItem>(){
            override fun areItemsTheSame(
                oldItem: ItemsItem,
                newItem: ItemsItem
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: ItemsItem,
                newItem: ItemsItem
            ): Boolean {
                return oldItem == newItem
            }
        }
    }
}