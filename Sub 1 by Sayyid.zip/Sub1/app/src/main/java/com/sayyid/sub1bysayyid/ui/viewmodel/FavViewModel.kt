package com.sayyid.sub1bysayyid.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sayyid.sub1bysayyid.data.local.FavUser
import com.sayyid.sub1bysayyid.data.local.repository.FavUserRepository
import com.sayyid.sub1bysayyid.data.response.GithubResponse
import com.sayyid.sub1bysayyid.data.response.ItemsItem
import com.sayyid.sub1bysayyid.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FavViewModel(application: Application) : ViewModel() {
    private val repo = FavUserRepository(application)

    fun getAllFavUser(): LiveData<List<FavUser>> = repo.getAllFavUser()

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    private val _itemsItem = MutableLiveData<List<ItemsItem>>()
    val itemsItem: LiveData<List<ItemsItem>> = _itemsItem

}